
class Normalise:
    pass


class Present:
    pass


class Clean:
    pass


class Validate:
    pass


class Split:
    # A class for splitting data
    # into training and test sets
    pass

class Impute:
    pass


class Visualize:
    pass
