import unittest

class TestCache(unittest.TestCase):

    def test_get(self):
        pass

    def test_set(self):
        pass

    def test_del(self):
        pass