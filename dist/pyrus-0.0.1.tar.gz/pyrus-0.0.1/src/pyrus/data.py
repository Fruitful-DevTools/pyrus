"""
The data.py module holds multiple classes and functions for managing and handling
data inside of python.
"""

import datetime
import unicodedata

class Normalise:
    
    def __init__(self, data):
        self.data = data

    def normalise(self):

        if isinstance(self.data, str):
            return NormaliseString.normalise()
        
        elif isinstance(self.data, int):
            return NormaliseInt.normalise()
        
        elif isinstance(self.data, float):
            return NormaliseFlt.normalise()
        
        else:
            raise TypeError("Normalise input must be string, integer or float datatype.")

class NormaliseString(Normalise):
    """A subclass of Normalise that normalizes string data.
    
    This subclass provides a method for normalizing string data by performing
    several operations:
    - Converting all characters to lowercase
    - Removing leading/trailing white space
    - Removing double spaces
    - Replacing accented and special characters with their ASCII equivalents
    """
    def normalise(self) -> str:
        """Normalize the string data.
        
        This method normalises string data by performing several operations:
        - Converting all characters to lowercase
        - Removing leading/trailing white space
        - Removing double spaces
        - Replacing accented and special characters with their ASCII equivalents
        
        Returns:
            data (str): The normalized string data.
        """
        data = self.data.lower()
        data = data.strip()
        data = data.replace('  ', ' ')
        data = unicodedata.normalize('NFKD', data).encode('ASCII', 'ignore').decode()
        return data

class NormaliseInt(Normalise):

    def normalise(self):
        pass

class NormaliseFlt(Normalise):

    def normalise(self):
        pass

class Present(Normalise):
    pass


class Clean:
    pass